"""
This code was written by [Mehrnaz Niazi] and is for classifying text data from 
the Spooky Authors (train)dataset, which can bedownloaded from Kaggle
(https://www.kaggle.com/competitions/spooky-author-identification/data). 
The dataset is used to train four machine learning models, including an 
MLP, LSTM, CNN, and RNN, to classify the text into three categories(authors).
The code preprocesses the text data by vectorizing it using Tf-idf, padding
the sequences to the same length, and encoding the labels. The models are then 
trained and their performance is visualized using plots of the mean squared error
and accuracy during training, as well as ROC curves for each model.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from keras.utils import np_utils
from keras.preprocessing.text import Tokenizer

from keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from keras.preprocessing.text import Tokenizer
from keras_preprocessing.sequence import pad_sequences
from keras.models import Sequential

from keras.layers import Flatten
from keras.layers import Dense, Embedding, LSTM, SpatialDropout1D
from keras.layers.convolutional import Conv1D, MaxPooling1D
from keras.layers import GRU, BatchNormalization, Conv1D, MaxPooling1D
import sklearn 
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer

# Load the train and test data
data = pd.read_csv('/content/train.csv')
data_text = data['text'].values

# Initialize the TfidfVectorizer
vectorizer = TfidfVectorizer(max_features=5000, stop_words='english', max_df=0.9, min_df=3, ngram_range=(1,2))
# Fit and transform the training data
X_data = vectorizer.fit_transform(data_text).toarray()
max_length = max(len(x) for x in X_data.tolist())

# Encode the train target labels
encoder = LabelEncoder()
encoder.fit(data.author)
Y_data = encoder.transform(data.author)
Y_data = np_utils.to_categorical(Y_data)
num_words = len(vectorizer.vocabulary_)
train_data,test_data,train_target,test_target=train_test_split(X_data,Y_data, test_size=0.2, random_state=60)


def train_mlp(X_train, y_train, X_test, y_test):
  model = Sequential()
  model.add(Dense(128, input_shape=(X_train.shape[1],), activation='relu'))
  model.add(Dropout(0.5))
  model.add(Dense(3, activation='softmax'))
  model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['mean_squared_error', 'accuracy'])
  history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=50)
  return history

def train_lstm(X_train, y_train, X_test, y_test, max_length):
  model = Sequential()
  model.add(Embedding(X_train.shape[1], 128, input_length=max_length))
  model.add(LSTM(128, dropout=0.5, recurrent_dropout=0.5)) 
  model.add(Dense(3, activation='softmax'))
  model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['mean_squared_error', 'accuracy'])
  history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=50)
  return history

def train_cnn(X_train, y_train, X_test, y_test, max_length):
  model = Sequential()
  model.add(Embedding(X_train.shape[1], 128, input_length=max_length))
  model.add(Conv1D(filters=32, kernel_size=3, padding='same', activation='relu'))
  model.add(MaxPooling1D(pool_size=2))
  model.add(Dropout(0.5))
  model.add(Bidirectional(LSTM(128)))
  model.add(Dense(3, activation='softmax'))
  model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['mean_squared_error', 'accuracy'])
  history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=50)
  return history

def train_rnn(X_train, y_train, X_test, y_test):
  model = Sequential()
  model.add(Embedding(num_words, 128, input_length=max_length))
  model.add(GRU(128, dropout=0.5, recurrent_dropout=0.5))
  model.add(Dense(3, activation='softmax'))
  model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['mean_squared_error', 'accuracy'])
  history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=50)
  return history

models=['MLP', 'LSTM', 'CNN', 'RNN']
# Train and evaluate the models
histories = []
for model in models:
        if model == 'MLP':
            history = train_mlp(train_data,train_target,test_data,test_target)
        if model == 'LSTM':
            history = train_lstm(train_data,train_target,test_data,test_target, max_length)
        elif model == 'CNN':
            history = train_cnn(train_data,train_target,test_data,test_target, max_length)
        elif model == 'RNN':
            history = train_rnn(train_data,train_target,test_data,test_target)
        histories.append(history)
        
# Set up the subplots
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12,8))

# Plot the mean squared error values
for history in histories:
  ax1.plot(history.history['mean_squared_error'])
ax1.set_title('Mean Squared Error')
ax1.set_ylabel('MSE')
ax1.set_xlabel('Epoch')
ax1.legend(['MLP', 'LSTM', 'CNN', 'RNN'], loc='upper left')

# Plot the accuracy values
for history in histories:
  ax2.plot(history.history['accuracy'])
ax2.set_title('Accuracy')
ax2.set_ylabel('Accuracy')
ax2.set_xlabel('Epoch')
ax2.legend(['MLP', 'LSTM', 'CNN', 'RNN'], loc='upper left')

# Show the plot
plt.show()

# Calculate the ROC curves for the LSTM and CNN models
fpr_mlp, tpr_mlp, thresholds_mlp = roc_curve(test_target[:,0], histories[0].model.predict(test_data)[:,0])
fpr_lstm, tpr_lstm, thresholds_lstm = roc_curve(test_target[:,0], histories[1].model.predict(test_data)[:,0])
fpr_cnn, tpr_cnn, thresholds_cnn = roc_curve(test_target[:,0], histories[2].model.predict(test_data)[:,0])
fpr_rnn, tpr_rnn, thresholds_rnn = roc_curve(test_target[:,0], histories[3].model.predict(test_data)[:,0])

# Plot the ROC curves
plt.figure(figsize=(12,8))
plt.plot(fpr_mlp, tpr_mlp)
plt.plot(fpr_lstm, tpr_lstm)
plt.plot(fpr_cnn, tpr_cnn)
plt.plot(fpr_rnn, tpr_rnn)

plt.title('ROC Curves')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(['MLP', 'LSTM', 'CNN', 'RNN'], loc='lower right')
plt.show()
        